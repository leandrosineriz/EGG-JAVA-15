package Servicios;

import Entidades.Clientes;
import Persistencia.ClientesDAO;
import java.util.Scanner;

public class ClientesService {

    private Scanner in;
    private ClientesDAO dao;

    public ClientesService() {
        this.in = new Scanner(System.in);
        this.dao = new ClientesDAO();
    }

    //e) Listar los datos de todos los clientes que en algún momento realizaron una estancia y la
    //descripción de la casa donde la realizaron.
    public void ListarClientes() throws Exception {
        Clientes cliente = new Clientes();

        try {

        } catch (Exception e) {
            throw e;
        }
    }

}
