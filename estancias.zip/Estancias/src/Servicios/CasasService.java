
package Servicios;

import Entidades.Casas;
import Persistencia.CasasDAO;
import java.util.Scanner;

public class CasasService {
    private Scanner in;
    private CasasDAO dao;

    public CasasService() {
        this.in = new Scanner(System.in);
        this.dao = new CasasDAO();
    }
    
    // g) Ingresar un fabricante a la base de datos
    public void ingresarCasas ()throws Exception{
        Casas casas = new Casas();
        System.out.print("Nombre casa -> ");
       casas.(in.nextLine());
        
        try {
            dao.guardarFabricante(f);
        } catch (Exception e) {
            throw e;
        }
    }
    
    
    
}
}
