
package Persistencia;

public class EstanciasDAO {
    
}
