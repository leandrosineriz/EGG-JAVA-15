
package Persistencia;

public class CasasDAO {
    
}
