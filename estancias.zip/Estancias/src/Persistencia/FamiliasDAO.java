
package Persistencia;

public class FamiliasDAO {
    
}
