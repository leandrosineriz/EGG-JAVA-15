
package Persistencia;

public class ComentariosDAO {
    
}
